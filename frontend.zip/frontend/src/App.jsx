import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [selectedStock, setSelectedStock] = useState('');
  const [stockPrice, setStockPrice] = useState(null);

  useEffect(() => {
    if (selectedStock) {
      const fetchData = async () => {
        try {
          const response = await fetch(`http://localhost:5000/stockPrice?symbol=${selectedStock}`);
          const data = await response.json();
          setStockPrice(data.price);
        } catch (error) {
          console.error('Error fetching stock price:', error);
        }
      };

      fetchData(); 

      const intervalId = setInterval(fetchData, 60000); // Update every minute

      return () => clearInterval(intervalId);
    }
  }, [selectedStock]);

  return (
    <div className="py-4 shadow-2xl">
      <h1 className='text-blue-600 text-3xl py-4'>Mini Stock Price Tracker</h1>
      <div className="selector text-blue-600 text-3xl">
        <select
          id="stock-selector" className='text-blue-600 text-3xl'
          value={selectedStock}
          onChange={(e) => setSelectedStock(e.target.value)}
        >
         
          <option value="">Select a stock</option>
          <option value="Tcs">Tata consultancy services</option>
          <option value="Wipro">Wipro Corporation </option>
          <option value="Amazon">Amazon.com Inc</option>
          <option value="Google">Google Inc </option>
          <option value="Infosys">Infosys Inc</option>

        </select>
      </div>
      <div className="price-display">
        {selectedStock && (
          <p className='text-blue-600 text-3xl py-4'>
            Current Price for {selectedStock}: ${stockPrice}
          </p>
        )}
      </div>
    </div>
  );
}

export default App;
