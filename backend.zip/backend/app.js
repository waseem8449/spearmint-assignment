const express = require('express');
const cors = require('cors');

const stockModel = require('./model/stock.model');
const app = express();
app.use(cors());
const port = 5000;
require("./db")

const stocks = [
  { name: 'Tata consultancy services.', symbol: 'Tcs' },
  { name: 'Wipro Corporation', symbol: 'Wipro' },
  { name: 'Amazon.com Inc.', symbol: 'Amazon' },
  { name: 'Alphabet Inc. (Google)', symbol: 'Google' },
  { name: 'Infosys Inc', symbol: 'Infosys' },

];

function getRandomStockPrice() {
  return (Math.random() * (200 - 50) + 50).toFixed(2); 
}

app.get('/stockprice', async(req, res) => {
  const { symbol } = req.query;
  const stock = stocks.find((stock) => stock.symbol === symbol);

  if (!stock) {
    return res.status(404).json({ error: 'Stock not found' });
  }

  const price = getRandomStockPrice();
  const newStock = new stockModel({
    name: stock.name,
    symbol: stock.symbol,
    price: parseFloat(price),
  });

  try {
    await newStock.save();
    res.json({ stock: stock.name, symbol: stock.symbol, price });
  } catch (error) {
    console.error('Error saving stock data to MongoDB:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(` server is running on port ${port}`);
});

// const express = require('express');
// // const faker = require('faker');
// import faker from "faker"
// const cors = require('cors');

// const app = express();
// const port = process.env.PORT || 5000;

// app.use(express.json());
// app.use(cors());

// // Mock data for predefined stocks with random prices
// const stocks = {
//   AAPL: { price: 150.0 },
//   GOOGL: { price: 2700.0 },
//   AMZN: { price: 3450.0 },
//   TSLA: { price: 700.0 },
//   MSFT: { price: 300.0 },
// };

// // Endpoint to get the price of a specific stock
// app.get('/api/stocks/:symbol', async (req, res) => {
//   try {
//     // List of predefined stock symbols
//     const stockSymbols = ['AAPL', 'GOOGL', 'AMZN', 'TSLA', 'MSFT'];

//     // Generate random stock prices
//     const stocks = stockSymbols.map((symbol) => ({
//       symbol,
//       price: faker.finance.amount(50, 500, 2), // Random price between 50 and 500 with 2 decimal places
//     }));

//     // Save the generated data to the database
//     // await Stock.insertMany(stocks);

//     return res.json(stocks);
//   } catch (error) {
//     console.error('Error:', error);
//     return res.status(500).json({ error: 'Internal server error' });
//   }
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });

// // app.js
// const express = require('express');
// const app = express();
// const faker = require('faker');
// const Stock = require('.stock.model');
// // require('./db');

// const PORT = process.env.PORT || 3000;

// app.use(express.json());

// // Mock API endpoint to generate random stock prices for predefined stocks
// app.get('/api/stocks', async (req, res) => {
  // try {
  //   // List of predefined stock symbols
  //   const stockSymbols = ['AAPL', 'GOOGL', 'AMZN', 'TSLA', 'MSFT'];

  //   // Generate random stock prices
  //   const stocks = stockSymbols.map((symbol) => ({
  //     symbol,
  //     price: faker.finance.amount(50, 500, 2), // Random price between 50 and 500 with 2 decimal places
  //   }));

  //   // Save the generated data to the database
  //   await Stock.insertMany(stocks);

  //   return res.json(stocks);
  // } catch (error) {
  //   console.error('Error:', error);
  //   return res.status(500).json({ error: 'Internal server error' });
  // }
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });
