// db.js
const mongoose = require('mongoose');
let url='mongodb+srv://waseem8449:waseem@cluster0.1rdpngo.mongodb.net/stockss'//put mongodb url string here
mongoose.connect(url, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});
